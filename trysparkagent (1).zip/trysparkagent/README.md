# SparkAgent — try.sparkagent.in.net

The public landing + authentication website for SparkAgent. This site's
only job is to introduce SparkAgent and authenticate users — after signing
in, users are sent to the app at **https://agent.sparkagent.in.net**.

There is no dashboard, no chat UI, and no "you're all set" page here.

## Stack

- Next.js 14 (App Router) + TypeScript
- Tailwind CSS
- Supabase Auth (`@supabase/supabase-js` + `@supabase/ssr`, cookie-based sessions)
- Deployed on Netlify (`main` branch auto-deploys)

## Local setup

```bash
npm install
cp .env.example .env.local
# fill in .env.local with your Supabase project's URL + anon key
npm run dev
```

Open http://localhost:3000.

## Environment variables

| Variable | Where it's used | Notes |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | browser + server | `https://nzaelikbjumaidaombmp.supabase.co` |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | browser + server | The **anon/publishable** key only. Never set a service-role key here or anywhere in this repo. |

Set both in **Netlify → Site settings → Environment variables** for
production. `.env.local` is git-ignored and must never be committed.

## Supabase project configuration

In the Supabase dashboard for `nzaelikbjumaidaombmp`:

1. **Authentication → URL Configuration**
   - Site URL: `https://try.sparkagent.in.net`
   - Redirect URLs (allow list) — add **both** if you test locally:
     - `https://try.sparkagent.in.net/auth/callback`
     - `http://localhost:3000/auth/callback`

   The app now sends `redirectTo`/`emailRedirectTo` as
   `${window.location.origin}/auth/callback`, so it works from either
   host — but Supabase will silently ignore any `redirectTo` that isn't
   in this allow list and fall back to the Site URL instead, which is
   what causes a stray `?code=...` to show up on `/` instead of the
   session being created on `/auth/callback`. If that ever happens, the
   homepage now also detects a leftover `code` param and completes the
   sign-in itself as a fallback — but fixing the allow list above is the
   real fix.
2. **Authentication → Providers**
   - Enable **Google** and **GitHub**, each with their own OAuth client
     ID/secret, and set each provider's authorized redirect URI to the
     Supabase-provided callback (`https://nzaelikbjumaidaombmp.supabase.co/auth/v1/callback`) — Supabase then forwards to this app's
     `/auth/callback` route automatically.
3. **SQL editor** — run [`supabase/schema.sql`](./supabase/schema.sql) once.
   It creates the `profiles` table, a trigger that auto-generates a
   `usr_xxxxxx` code for every new user, and Row Level Security policies so
   a user can only ever read/update their own row. It also lays the
   groundwork (`chats` table) for future chat URLs at
   `agent.sparkagent.in.net/c/{user_code}/{chat_code}` — this repo does not
   read from or write to that table.

## Auth flow

- **Email/password sign in** → `supabase.auth.signInWithPassword` → on
  success, redirect to `https://agent.sparkagent.in.net`.
- **Email/password sign up** → `supabase.auth.signUp` with
  `emailRedirectTo: https://try.sparkagent.in.net/auth/callback` → user
  confirms via email → Supabase redirects to `/auth/callback` → the route
  handler exchanges the code for a session → redirect to
  `https://agent.sparkagent.in.net`.
- **Google / GitHub** → `supabase.auth.signInWithOAuth` with the same
  `redirectTo` → same `/auth/callback` exchange → same final redirect.

The redirect destination in `app/auth/callback/route.ts` is a hardcoded
constant, never read from a query parameter, so the endpoint can't be used
as an open redirect.

## Project structure

```
app/
  page.tsx              # landing + auth page
  layout.tsx            # fonts, metadata
  globals.css
  auth/callback/route.ts # OAuth + email-verification callback
components/
  Header.tsx, Hero.tsx, BrowserMockup.tsx, Features.tsx,
  AuthCard.tsx, Footer.tsx, icons.tsx
lib/supabase/
  client.ts             # browser client
  server.ts             # server component / route handler client
  middleware.ts         # session refresh helper
middleware.ts
supabase/schema.sql
```

## Deployment (Netlify)

This repo includes `netlify.toml` configured for
`@netlify/plugin-nextjs`. Connect the `main` branch of
`github.com/Vexedhere/trysparkagent`, set the two environment variables
above in the Netlify dashboard, and Netlify will build and deploy on every
push.

## Security notes

- No service-role key is ever used in this repo — only the public anon key,
  which is safe to expose to the browser and is meant to be combined with
  Row Level Security (already enabled on every table in `schema.sql`).
- Sessions are stored in secure, httpOnly cookies via `@supabase/ssr`, not
  `localStorage`.
- `middleware.ts` refreshes the session cookie on every request; it never
  redirects, since this site has no protected pages of its own.
- The `/auth/callback` redirect target is hardcoded — see "Auth flow" above.

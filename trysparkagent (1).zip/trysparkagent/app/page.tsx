import { redirect } from "next/navigation";
import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { BrowserMockup } from "@/components/BrowserMockup";
import { Features } from "@/components/Features";
import { AuthCard } from "@/components/AuthCard";
import { Footer } from "@/components/Footer";
import { createClient } from "@/lib/supabase/server";

const APP_URL = "https://agent.sparkagent.in.net";

export default async function HomePage({
  searchParams,
}: {
  searchParams: { code?: string };
}) {
  // Defense in depth: the OAuth/email flow should always land on
  // /auth/callback (see that route for the primary exchange + the
  // hardcoded, non-open redirect). If a Supabase Site URL / redirect
  // allow-list mismatch ever sends the code here instead, complete the
  // sign-in anyway rather than stranding the user on a page with an
  // unused `code` param in the address bar.
  if (searchParams.code) {
    const supabase = createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(searchParams.code);
    if (!error) {
      redirect(APP_URL);
    }
  }

  return (
    <>
      <div className="bg-grid-canvas" />

      {/* ambient glow accents */}
      <div
        className="animate-glow-move pointer-events-none fixed left-1/2 top-[-10%] z-0 h-[520px] w-[820px] -translate-x-1/2 rounded-full bg-spark-gradient-soft blur-[110px]"
        aria-hidden="true"
      />

      <div className="relative z-10">
        <Header />
        <main>
          <Hero />
          <BrowserMockup />
          <Features />
          <AuthCard />
        </main>
        <Footer />
      </div>
    </>
  );
}

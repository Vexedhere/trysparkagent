import { Sparkles } from "lucide-react";

export function Hero() {
  return (
    <section id="home" className="relative px-6 pt-20 pb-16 lg:pt-28 lg:pb-24">
      <div className="mx-auto flex max-w-[1280px] flex-col items-center text-center">
        <div className="animate-fade-up mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-4 py-1.5">
          <Sparkles className="h-3.5 w-3.5 text-spark-indigo" />
          <span className="font-body text-[13px] font-medium text-ink-muted">
            Next-gen AI platform
          </span>
        </div>

        <h1
          className="animate-fade-up max-w-[780px] font-heading text-[38px] font-medium leading-[1.15] tracking-tight text-ink sm:text-[48px] lg:text-[58px]"
          style={{ animationDelay: "80ms" }}
        >
          Your AI workspace,{" "}
          <span className="text-gradient font-bold">reimagined.</span>
        </h1>

        <p
          className="animate-fade-up mt-6 max-w-[620px] font-body text-[17px] leading-relaxed text-ink-muted lg:text-[18px]"
          style={{ animationDelay: "160ms" }}
        >
          SparkAgent brings smarter conversations, instant document analysis,
          and automated desktop workflows into a single focused workspace —
          sign in to pick up right where your team left off.
        </p>

        <div
          className="animate-fade-up mt-9 flex w-full flex-col items-center gap-3 sm:w-auto sm:flex-row"
          style={{ animationDelay: "240ms" }}
        >
          <a
            href="#auth"
            data-auth-intent="signup"
            className="w-full rounded-full bg-spark-gradient px-7 py-3 text-center font-body text-[15px] font-semibold text-white shadow-glow transition-transform hover:scale-[1.02] sm:w-auto"
          >
            Get started
          </a>
          <a
            href="#auth"
            data-auth-intent="signin"
            className="w-full rounded-full border border-white/12 bg-white/[0.03] px-7 py-3 text-center font-body text-[15px] font-medium text-ink transition-colors hover:bg-white/[0.07] sm:w-auto"
          >
            Sign in
          </a>
        </div>
      </div>
    </section>
  );
}
